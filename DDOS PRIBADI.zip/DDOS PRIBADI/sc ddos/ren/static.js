import crypto from 'crypto';

// ANSI color codes for terminal output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m',
  bgBlue: '\x1b[44m',
  bgGreen: '\x1b[42m',
  bgRed: '\x1b[41m'
};

// Function to calculate hash of content
function calculateHash(content) {
  return crypto.createHash('sha256').update(content).digest('hex');
}

// Function to generate a random query parameter
function getRandomParam() {
  return `nocache=${Date.now()}-${Math.random().toString(36).substring(2, 15)}`;
}

// Function to add a random query parameter to a URL
function addRandomParamToUrl(urlString) {
  const url = new URL(urlString);
  url.searchParams.append('nocache', getRandomParam());
  return url.toString();
}

// Progress bar function
function updateProgressBar(current, total, barLength = 30) {
  const progress = Math.round((current / total) * barLength);
  const progressBar = '█'.repeat(progress) + '░'.repeat(barLength - progress);
  const percentage = Math.round((current / total) * 100);
  process.stdout.write(`\r${colors.bright}[${progressBar}] ${percentage}%${colors.reset}`);
  if (current === total) process.stdout.write('\n');
}

// Function to check if a URL is static
async function analyzeUrl(url, options = {}) {
  const {
    numRequests = 5,
    delayMs = 1500,
    timeout = 10000,
    userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15',
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
      'Mozilla/5.0 (iPhone; CPU iPhone OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15',
      'Mozilla/5.0 (iPad; CPU OS 14_7_1 like Mac OS X) AppleWebKit/605.1.15'
    ]
  } = options;

  console.log(`\n${colors.bgBlue}${colors.bright} URL STATIC CONTENT ANALYZER ${colors.reset}\n`);
  console.log(`${colors.bright}Target URL:${colors.reset} ${colors.cyan}${url}${colors.reset}`);
  console.log(`${colors.bright}Configuration:${colors.reset} ${numRequests} requests, ${delayMs}ms delay, ${timeout}ms timeout\n`);

  try {
    // Validate URL format
    new URL(url);
    
    const results = [];
    const startTime = Date.now();
    
    console.log(`${colors.yellow}Starting analysis...${colors.reset}\n`);
    
    // Make multiple requests to the URL
    for (let i = 0; i < numRequests; i++) {
      updateProgressBar(i, numRequests);
      
      const requestUrl = addRandomParamToUrl(url);
      const userAgent = userAgents[i % userAgents.length];
      const requestStartTime = Date.now();
      
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), timeout);
        
        const response = await fetch(requestUrl, {
          headers: {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
            'Expires': '0',
            'User-Agent': userAgent
          },
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);
        
        const responseTime = Date.now() - requestStartTime;
        const content = await response.text();
        const contentHash = calculateHash(content);
        const contentLength = content.length;
        
        // Extract important headers
        const headers = {
          'content-type': response.headers.get('content-type'),
          'last-modified': response.headers.get('last-modified'),
          'etag': response.headers.get('etag')
        };
        
        const headerHash = calculateHash(JSON.stringify(headers));
        
        results.push({
          requestNumber: i + 1,
          timestamp: new Date().toISOString(),
          statusCode: response.status,
          responseTime: responseTime,
          contentLength: contentLength,
          contentHash: contentHash.substring(0, 8),
          headerHash: headerHash.substring(0, 8)
        });
      } catch (error) {
        results.push({
          requestNumber: i + 1,
          timestamp: new Date().toISOString(),
          error: error.name === 'AbortError' ? 'Request timeout' : error.message
        });
      }
      
      // Wait between requests
      if (i < numRequests - 1) {
        await new Promise(resolve => setTimeout(resolve, delayMs));
      }
    }
    
    updateProgressBar(numRequests, numRequests);
    const totalTime = Date.now() - startTime;
    
    // Analyze results
    const validResults = results.filter(r => !r.error);
    const successRate = (validResults.length / numRequests) * 100;
    
    // Check if content is static
    const contentHashes = validResults.map(r => r.contentHash);
    const uniqueContentHashes = new Set(contentHashes);
    const isContentStatic = uniqueContentHashes.size === 1 && validResults.length > 0;
    
    // Check if headers are static
    const headerHashes = validResults.map(r => r.headerHash);
    const uniqueHeaderHashes = new Set(headerHashes);
    const areHeadersStatic = uniqueHeaderHashes.size === 1 && validResults.length > 0;
    
    // Calculate average response time
    const avgResponseTime = validResults.length > 0 
      ? validResults.reduce((sum, r) => sum + r.responseTime, 0) / validResults.length 
      : 0;
    
    // Print results table
    console.log(`\n${colors.bright}Detailed Request Results:${colors.reset}`);
    console.table(results.map(r => ({
      '#': r.requestNumber,
      'Status': r.statusCode || (r.error ? '❌' : '-'),
      'Time (ms)': r.responseTime || '-',
      'Content Hash': r.contentHash || '-',
      'Header Hash': r.headerHash || '-',
      'Size (bytes)': r.contentLength || '-',
      'Error': r.error || '-'
    })));
    
    // Print summary
    console.log(`\n${colors.bright}Analysis Summary:${colors.reset}`);
    
    const summaryTable = [
      {
        'Metric': 'Content Static',
        'Value': isContentStatic ? `${colors.green}YES${colors.reset}` : `${colors.red}NO${colors.reset}`,
        'Details': `${uniqueContentHashes.size} unique content version(s)`
      },
      {
        'Metric': 'Headers Static',
        'Value': areHeadersStatic ? `${colors.green}YES${colors.reset}` : `${colors.yellow}NO${colors.reset}`,
        'Details': `${uniqueHeaderHashes.size} unique header version(s)`
      },
      {
        'Metric': 'Success Rate',
        'Value': `${successRate.toFixed(1)}%`,
        'Details': `${validResults.length}/${numRequests} successful requests`
      },
      {
        'Metric': 'Avg Response Time',
        'Value': `${avgResponseTime.toFixed(2)} ms`,
        'Details': `Total analysis time: ${(totalTime / 1000).toFixed(2)} seconds`
      }
    ];
    
    console.table(summaryTable);
    
    // Final verdict
    console.log('\n📊 ' + colors.bright + 'Final Verdict: ' + colors.reset + 
      (isContentStatic 
        ? colors.bgGreen + ' STATIC CONTENT ' 
        : colors.bgRed + ' DYNAMIC CONTENT ') + 
      colors.reset + '\n');
    
    return {
      url,
      isStatic: isContentStatic,
      staticHeaders: areHeadersStatic,
      successRate,
      avgResponseTime,
      uniqueVersions: uniqueContentHashes.size,
      totalTime
    };
    
  } catch (error) {
    console.error(`\n${colors.red}Error analyzing URL: ${error.message}${colors.reset}`);
    return null;
  }
}

// Get URL from command line arguments or use default
const url = process.argv[2];

if (!url) {
  console.log(`
${colors.yellow}⚠️  No URL provided${colors.reset}

${colors.bright}Usage:${colors.reset}
  node premium-static-detector.js <url> 

${colors.bright}Example:${colors.reset}
  node premium-static-detector.js https://example.com
  
Please provide a URL to analyze.
`);
} else {
  analyzeUrl(url);
}